import numpy as np
import sympy as sp
from gate_sim_gates import *

def get_indices(bit_string:str):
    indices_list = []
    for char in bit_string:
        assert char == '0' or char == '1'
        indices_list.append(int(char))
    return tuple(indices_list)

def initialize_state(bit_string:str):
    n:int = len(bit_string)
    for char in bit_string:
        assert char == '0' or char == '1'
    tensor = np.zeros([2] * n, dtype=object)
    tensor[get_indices(bit_string)] = 1
    return tensor

def apply_1q_gate(state, gate, qubit):
    n:int = state.ndim
    assert qubit >= 0 and qubit < n
    state = np.moveaxis(state, qubit, 0)
    state = np.tensordot(gate, state, axes=([1], [0]))
    state = np.moveaxis(state, 0, qubit)
    return state

def eval_probability(qubit_matrix:np.ndarray)->dict:
    qubits = qubit_matrix.ndim
    qubit_matrix = qubit_matrix.reshape(-1)
    assert qubit_matrix.ndim == 1
    possibilities:int = qubit_matrix.shape[0]
    squared = np.square(qubit_matrix)
    # print(squared)
    probabilities = {}
    for i in range(possibilities):
        binary:str = ("{0:0%db}"%(qubits)).format(i)
        if squared[i] > 0:
            probabilities[binary] = squared[i]
    return probabilities

def eval_state(qubit_matrix:np.ndarray)->None:
    qubits = qubit_matrix.ndim
    state_vector = qubit_matrix.reshape(-1)
    assert state_vector.ndim == 1
    states = [f"|{bin(i)[2:].zfill(qubits)}⟩" for i in range(2**qubits)]

    print("Final state amplitudes:")
    for idx, amplitude in enumerate(state_vector):
        if amplitude == 0:
            continue
        print(f'{states[idx]}: {amplitude}')

    norm = sum(sp.Matrix(np.abs(state_vector ** 2)))
    print(f'\nNormalization check (should be 1): {norm}')

state = initialize_state("01000")
state = apply_1q_gate(state, H, 3)
state = apply_1q_gate(state, H, 2)
state = apply_1q_gate(state, Y, 2)
eval_state(state)
